class Serra{
    constructor(x,y,width,height,angle) {
        var options = {
            isStatic: true
        }
        this.image = loadImage("serra.png");
        this.body = Bodies.rectangle(x, y, width, height, options);
        this.width = width;
        this.height = height;
        this.angle = angle;
        World.add(world, this.body);
    }

    display(){
        
        
        
        
        push();
        
        angleMode(DEGREES);
        var angle = this.body.angle+=1;
        rotate(angle);
      
        imageMode(CENTER);
        image(this.image,this.body.position.x,this.body.position.y, this.width, this.height);
       
        pop();
        
      }
     
      
}
 