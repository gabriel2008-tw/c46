// <-- constantes matter --> //
const Engine = Matter.Engine;
const World= Matter.World;
const Bodies = Matter.Bodies;
const Constraint = Matter.Constraint;
// <--               //               --> //
// <-- variaveis matter --> //
var engine, world;
// <--               //               --> //

// <-- variaveis das imagens --> //
    var runAnimation, slideAnimation,dieAnimation;
     var  defaultAnimation, jumpingAnimation, coinImage;
     var canvas;
// <--               //               --> //

// <-- variaveis dos personagens e objetos --> //
    var Rob;
    var platform;
    var obstaculo1, serra;
    var obstaculo2, barril;
    var obstaculo3,espinhos;
    var obstaculo4,acido;
    var obstaculo5,grade1;
    var obstaculo6,moeda;
    var obstaculo7;
    var obstaculo8;
// <--               //               --> //

// <-- preload --> //
function preload(){


}
// <--               //               --> //

// <-- setup --> //
function setup(){
    canvas = createCanvas(windowWidth,windowHeight);

    engine = Engine.create();
    world = engine.world;

    Rob = new ROB(width/10,height/3,width/10,height/10);
    platform = new Platform(width/10,height/2,width/10,height/7);
    obstaculo1 = new Obstaculo1(width/3,height/2,width/10,height/7);
    obstaculo2 = new Obstaculo2(width/2.35,height/2,width/10,height/7);
    obstaculo3 = new Obstaculo3(width/3.85,height/2,width/10,height/7);
    obstaculo4 = new Obstaculo1(width/1.9,height/1.75,width/10,height/7);
    obstaculo5 = new Obstaculo3(width/2.25,height/1.75,width/10,height/7);
    obstaculo6 = new Obstaculo2(width/1.65,height/1.75,width/10,height/7);
    obstaculo7 = new Obstaculo2(width/1.65,height/2,width/10,height/7);
    obstaculo8 = new Obstaculo2(width/1.435,height/2,width/10,height/7);
    grade1 = new Grade1(width/2.3,height/2.8,width/10,height/7);
    grade2 = new Grade2(width/1.9,height/2.8,width/10,height/7);
    grade3 = new Grade3(width/1.63,height/2.8,width/10,height/7);
    serra = new Serra(width/3-30,height/2-50,width/20,height/14)
    
    barril = new Barril(width/1.4,height/2.5,width/20,height/14)
    espinhos = new Espinhos(width/1.5,height/2.5,width/20,height/14)
    acido = new Acido(width/1.9,height/2.2,width/10,height/7)

    moeda= new Moeda(width/3,height/3,width/20,height/14)
}
// <--               //               --> //

// <-- draw --> //
function draw(){

    background("#828385");
    Engine.update(engine);

    Rob.display();
    platform.display();
    obstaculo1.display();
    obstaculo2.display();
    obstaculo3.display();
    obstaculo4.display();
    obstaculo5.display();
    obstaculo6.display();
    obstaculo7.display();
    obstaculo8.display();
    grade1.display();
    grade2.display();
    grade3.display();
    serra.display();
    barril.display();
    espinhos.display();
    acido.display();
    moeda.display();



}
// <--               //               --> //
